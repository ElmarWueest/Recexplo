data:extend({
	{
		type = "custom-input",
		name = "recexplo-open-gui",
		key_sequence = "CONTROL + F",
		consuming = "script-only"
	}
})

require("prototypes/styles")
require("prototypes/prototypes")
